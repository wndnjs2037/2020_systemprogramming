#include<stdio.h>

typedef unsigned char* pointer;

void show_bytes(pointer start, size_t len)
{
	size_t i;
	for( i = 0 ; i < len ; i++ )
	{
		printf("%p\t0x%.2x\n", start + i, start[i]);
	printf("\n");
	}
}

int main()
{
	int a = 20192795;
	printf("int a = %d \n", a);
	show_bytes((pointer) &a, sizeof(int));
	
	printf("my computer is little endian. \n");
	printf("\n");

	long b = 1234;
	printf("long b = %ld bit \n", sizeof(b));

	if (sizeof(b) == 4)
	{
		printf("CPU information(system kind) : 64 bit");
	}else{
		printf("CPU information(systme kind) : 32 bit");
	}

	return 0;
}

